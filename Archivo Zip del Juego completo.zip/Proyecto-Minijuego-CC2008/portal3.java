import greenfoot.*;

/**
 * Write a description of class portal3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class portal3 extends Actor
{
    /**
     * Act - do whatever the portal3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
