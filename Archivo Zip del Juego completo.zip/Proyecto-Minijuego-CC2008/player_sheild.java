import greenfoot.*;

/**
 * Write a description of class jack_sheild here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class player_sheild extends player
{
    /**
     * Act - do whatever the jack_sheild wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
    }    
}
